# BANKING_MANAGNEMENT_SYSTEM
Bank-Management-System
This is a Bank Management System Database Project.

Abstract: The main aim of Bank Management Mini DBMS project is to keep record of customer transactions in the bank.

We aim to demonstrate the use of create, read, update and delete MySQL operations through this project.

Firstly, employee registration is done in the concern bank branch.

Branch employee creates customer account in the bank, then customer can credit amount, debit amount and check balance.

Customer can even use different services like insurance, loan, bill payments etc.

Modules:

Bank Management Mini DBMS Project contains 4 modules:

Account Holder: As the name suggests, a record of customer details.

Transaction: Transactions to be made by the customer (credit amount, debit etc).

Services: Additional services that customer may want like (insurance, loan etc.).

Branch/Employee : Manager/Employee details of the concern bank.

SOFTWARE REQUIREMENTS:

• Language : Java

• IDE :  Eclipse/intellij

• Database : MYSQL (Install workbench)

Technologies used:

• JavaFX

• Mysql
